﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using mvc_using_api_entityframwork.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace mvc_using_api_entityframwork.Controllers
{
    public class CourseControllercs : Controller
    {
        private static List<MyCourse> course = new List<MyCourse>();
        private static HttpClient httpClient = new HttpClient();
        private string url = "";


        public CourseControllercs()
        {
            url = @"https://localhost:44370/api/Courses";
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        }

        
        // GET: CourseControllercs
        public async Task<ActionResult> Index()
        {
            var msg=await httpClient.GetAsync(url);
            var CourseResponse = msg.Content.ReadAsStringAsync();
            course = JsonConvert.DeserializeObject<List<MyCourse>>(CourseResponse.Result);


          
            return View(course);
        }

        // GET: CourseControllercs/Details/5
        public async Task<ActionResult> Details(int id)  
        {
            var msg= await httpClient.GetAsync(url+"/"+id);
            var CourseResponse = msg.Content.ReadAsStringAsync();
            MyCourse myCourse=JsonConvert.DeserializeObject<MyCourse>(CourseResponse.Result);

            return View(myCourse);
        }

        // GET: CourseControllercs/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CourseControllercs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(MyCourse myCourse)
        {
            try
            {
                StringContent courseContent = new StringContent(
                    JsonConvert.SerializeObject(myCourse), Encoding.UTF8, "application/json");
                var msg = await httpClient.PostAsync(url,courseContent);
                var CourseResponse=msg.Content.ReadAsStringAsync();

                if (CourseResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Create));
                }
                
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CourseControllercs/Edit/5
        public  async Task<ActionResult> Edit(int id)
        {
            return View(await getCourseById(id));
        }


        // POST: CourseControllercs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, MyCourse courseToEdit)
        {
            try
            {
                MyCourse myCourse = await getCourseById(id);
                myCourse.CourseName= courseToEdit.CourseName;
                StringContent courseContent = new StringContent(JsonConvert.SerializeObject(myCourse),
                    Encoding.UTF8, "application/json");

                var msg= await httpClient.PutAsync(url + "/" + id, courseContent);
                var CourseResponse = msg.Content.ReadAsStringAsync();
                course = JsonConvert.DeserializeObject<List<MyCourse>>(CourseResponse.Result);

                if (CourseResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Edit),id);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }


        private async Task<MyCourse> getCourseById(int id)
        {   
            var msg=await httpClient.GetAsync(url+"/"+id);
            var CourseResponse= msg.Content.ReadAsStringAsync();
            MyCourse myCourse = JsonConvert.DeserializeObject<MyCourse>(CourseResponse.Result);
            return myCourse;

        }

        // GET: CourseControllercs/Delete/5
        public async  Task<ActionResult> Delete(int id)
        {
            return View(await getCourseById(id));
        }

        // POST: CourseControllercs/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async  Task<ActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                var msg=await httpClient.DeleteAsync(url+"/"+id);
                var CourseResponse=msg.Content.ReadAsStringAsync();

                course= JsonConvert.DeserializeObject<List<MyCourse>>(CourseResponse.Result);

                if (CourseResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Delete),id);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
