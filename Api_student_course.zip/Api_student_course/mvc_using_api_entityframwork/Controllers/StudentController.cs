﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using mvc_using_api_entityframwork.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace mvc_using_api_entityframwork.Controllers
{
    public class StudentController : Controller
    {
        private static List<MyStudent> student = new List<MyStudent>();
        private static HttpClient httpClient = new HttpClient();
        private string url = "";
        public StudentController()
        {
            url = @"https://localhost:44370/api/Students";
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        }
        
        // GET: StudentController
        public  async Task<ActionResult> Index()
        {
            var msg = await httpClient.GetAsync(url);
            var StudentResponse=msg.Content.ReadAsStringAsync();
            student = JsonConvert.DeserializeObject<List< MyStudent >> (StudentResponse.Result);
            return View(student);
        }

        // GET: StudentController/Details/5
        public async Task<ActionResult> Details(int getStudentById)
        {

            return View(getStudentById);
        }

        // GET: StudentController/Create
        public ActionResult Create()
        {

            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(MyStudent myStudent)
        {
            try
            {

                StringContent studentcontent = new StringContent(
                    JsonConvert.SerializeObject(myStudent), Encoding.UTF8, "application/json");
                var msg= await httpClient.PostAsync(url, studentcontent);
                var studentResponse = msg.Content.ReadAsStringAsync();
                if(studentResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Create));
                };
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id,MyStudent studentToEdit)
        {
            try
            {
                MyStudent  myStudent=await getStudentById(id);
                myStudent.StudentName= studentToEdit.StudentName;
                StringContent studentContent = new StringContent(JsonConvert.SerializeObject(myStudent), Encoding.UTF8, "application/json");
                var msg=await httpClient.PutAsync(url+"/"+ id, studentContent);
                var studentResponse = msg.Content.ReadAsStringAsync();
                student = JsonConvert.DeserializeObject<List<MyStudent>>(studentResponse.Result);
                if (studentResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Edit),id);
                }
                            
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        private async Task<MyStudent> getStudentById(int id)
        {
            var msg=await httpClient.GetAsync(url+"/"+id);
            var StudentResponse=msg.Content.ReadAsStringAsync();
            MyStudent myStudent = JsonConvert.DeserializeObject<MyStudent>(StudentResponse.Result);

          return myStudent;

        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                var msg=await httpClient.DeleteAsync(url+"/"+id);
                var studentResponse=msg.Content.ReadAsStringAsync();

                student= JsonConvert.DeserializeObject<List<MyStudent>>(studentResponse.Result);
                if (studentResponse.Result.Contains("Conflict"))
                {
                    return RedirectToAction(nameof(Delete), id);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
