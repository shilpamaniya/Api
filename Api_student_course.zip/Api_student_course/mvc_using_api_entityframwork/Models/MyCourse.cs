﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mvc_using_api_entityframwork.Models
{
    public class MyCourse
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }
}
