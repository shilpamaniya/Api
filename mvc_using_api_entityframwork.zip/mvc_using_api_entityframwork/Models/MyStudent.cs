﻿namespace mvc_using_api_entityframwork.Models
{
    public class MyStudent
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public int ContectNo { get; set; }
        public int  CourseId { get; set; }
        public string CourseName { get; set; }

    }
}
